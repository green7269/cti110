import turtle

# Set up turtle
t = turtle.Turtle()
t.pensize(5)           # Set pen size
t.pencolor("green")    # Set pen color
t.speed(2)

# Function to draw the letter 'F'
def draw_F():
    t.setheading(90)   # Face up
    t.pendown()
    t.forward(100)
    t.right(90)
    t.forward(50)
    t.backward(50)
    t.right(90)
    t.forward(50)
    t.left(90)
    t.forward(35)
    t.penup()

# Function to draw the letter 'G'
def draw_G():
    t.setheading(0)      # Ensure turtle is facing right
    t.forward(50)        # Move to starting point of circle
    t.setheading(180)    # Face left to start drawing the G circle correctly
    t.pendown()
    t.circle(50, 270)    # Draw 270-degree arc
    t.left(90)
    t.forward(30)        # Horizontal line inside the G
    t.penup()

# Draw 'F'
draw_F()

# Move to the right without drawing
t.setheading(60)           # Face right
t.forward(50)            # Space between initials

# Draw 'G'
draw_G()

# Hide turtle and complete
t.hideturtle()
turtle.done()
